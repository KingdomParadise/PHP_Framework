<h1>Bildnachweise</h1>
<p>
    Das Layout der Website, die verwendeten Grafiken/Bilder sowie die sonstigen Inhalte sind urheberrechtlich geschützt. Eine Vervielfältigung oder Verwendung der Texte und Grafiken/Bilder in anderen elektronischen oder gedruckten Publikationen ist ohne ausdrückliche Zustimmung nicht gestattet.
</p>
<p>
    Nachfolgend eine Auflistung der verwendeten Grafiken/Bilder:
</p>
<table class="table">
	<thead>
        <tr>
            <th>Titel</th>
            <th>Autor</th>
            <th>Agentur</th>
            <th>Lizenznummer</th>
        </tr>
	</thead>
	@include('static.partials.imageLicencesTableBody')
</table>
