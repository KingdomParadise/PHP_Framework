<h1>Impressum</h1>
<p>Bittorrent Marketing GmbH<br />
Handelskai 94-96<br />
1200 Wien<br />
Österreich</p>
<p>Telefon: +43 1 205 77 600 44<br />
Telefax : +43 1 333 45 8585</br />
E-Mail: office@bittorrent.at<br />
<p>Steuernummer: AT U74730179<br />
Firmenregister: FN 516225f, Wien</p>
<p>Geschäftsführer:<br />
Marcus Hofer und Eur.Ing. Harald Hochmann</p>
<p>Datenschutzbeauftragter:<br />
Eur.Ing. Harald Hochmann</p>
<p>bittorrent® ist eine von der Bittorrent Marketing GmbH eingetragene Wortmarke.<br />
DPMA Register-Nr. 302019012101 (Anmeldetag: 06.06.2003)</p>
