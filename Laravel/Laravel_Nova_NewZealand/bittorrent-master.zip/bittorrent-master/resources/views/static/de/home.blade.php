<div class="p-5 text-center">
    <img src="{{asset('img/under-construction.jpeg')}}" class="img-fluid w-55"/>
</div>
