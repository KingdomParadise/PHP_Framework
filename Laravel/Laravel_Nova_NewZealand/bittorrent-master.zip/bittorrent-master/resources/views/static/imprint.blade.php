@extends('layouts.base')

@section('content')
    @include('static.de.imprint')
@endsection
