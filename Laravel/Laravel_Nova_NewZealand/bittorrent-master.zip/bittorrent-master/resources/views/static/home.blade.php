@extends('layouts.base')

@section('bodyClass', 'bg-white')

@section('content')
    @include('static.de.home')
@endsection
