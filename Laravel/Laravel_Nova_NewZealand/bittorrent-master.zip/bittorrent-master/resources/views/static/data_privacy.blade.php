@extends('layouts.base')

@section('content')
    @include('static.de.data_privacy')
@endsection
