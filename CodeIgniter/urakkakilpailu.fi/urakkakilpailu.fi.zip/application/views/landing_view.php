<body>
    <div class="wrapper">
        <header>
            <div class="row">
                <div class="col-6">
                    <div class="header_description">
                        <div class="row">
                        </div>
                    </div>
                </div>
                <div class="col-6">
                </div>
            </div>
        </header>
        <div class="body">
        </div>
        <footer>
        </footer>
    </div>
</body>
</html>